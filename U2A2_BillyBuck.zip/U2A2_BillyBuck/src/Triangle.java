/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author billy
 */
public class Triangle extends Shape {
    
    public Triangle() {
        areaPerTile = 0.18;
        pricePerTile = 1.50;
    }
    
}
