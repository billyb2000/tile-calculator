/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author billy
 */
public abstract class Shape {
    
    protected double areaPerTile;   // area of one tile (m²)
    protected double pricePerTile;  // price of one tile ($)

    public double getAreaPerTile() {
        return areaPerTile;
    }

    public double getPricePerTile() {
        return pricePerTile;
    }

    public double getTotalArea(int count) {
        return areaPerTile * count;
    }

    public double getTotalCost(int count) {
        return pricePerTile * count;
    }
}
    
    

